# -*- coding: utf-8 -*-

# from typing_extensions import Required
from http.client import UPGRADE_REQUIRED
from odoo import api, fields, models
from odoo.exceptions import RedirectWarning, UserError, ValidationError, AccessError
from odoo.tools import float_compare, date_utils, email_split, email_re, html_escape, is_html_empty
from odoo.tools.misc import formatLang, format_date, get_lang

from pickletools import uint1
from sqlite3 import Date
from tokenize import Double
import requests
import json

from datetime import date


import qrcode
import base64
import io
import pickle
# import barcode
from base64 import b64encode
from reportlab.lib import units
from reportlab.graphics import renderPM
from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.graphics.shapes import Drawing


class Courier_Model(models.Model):
    _name = "courier_model"
    _description = "Courier Model"

    name = fields.Char(string='Courier Name')
    courier_group = fields.Many2one('courier.group', string='Courier Group')
    courier_type = fields.Selection([('Daraz', 'Daraz'), ('Call Courier', 'Call Courier'), (
        'TCS', 'TCS'), ('Forrun', 'Forrun'), ('Trax', 'Trax'), ('LCS', 'LCS'),('self_pickup', 'Self Pickup')], string='Select Courier')
    # for All Courier
    url = fields.Char(string='Hit URL')
    # for TCS name will be IBM-X-ID
    api_key = fields.Char(string='API Key')
    # For Forrun AccountID
    account_id = fields.Char(
        string='Account ID', attrs="{'invisible': [('courier_type', '!=', 'Forrun')]}")
    # For TCS Username and Password
    # FOR LCS API_KEY and Password as API_password
    username = fields.Char(string='Username')
    password = fields.Char(string='Password')
    account_id_TCS = fields.Char(string='Account ID')
    # for Trax
    authorization = fields.Char(string='Authorization')
    pickup_address_id = fields.Char(String='Pickup Address ID')
    cost_center_id = fields.Char(string='Cost Center')


class Courier_Groups(models.Model):
    _name = "courier.group"
    _description = "Courier Group"

    name = fields.Char(string='Courier Group')
    courier_model_line = fields.One2many(
        'courier.group.line', "courier_group_id", string='Courier')


class Courier_Group_line(models.Model):
    _name = "courier.group.line"
    _description = "Courier Group Line"

    name = fields.Char(string='Group Line')
    courier_group_id = fields.Many2one('courier.group')
    courier_group_line = fields.Many2one('courier_model', string='Courier')


class Courier_Zones(models.Model):
    _name = 'courier.zone'
    _description = 'Courier Zone'

    name = fields.Char(string='Zone', required=True)
    courier_zone = fields.Many2one(
        'courier_model', string='Courier', required=True)
    courier_provinces = fields.Many2one(
        'courier.provinces', string='Province', required=True)


class Courier_Rates(models.Model):
    _name = 'courier.rates'
    _despriction = 'Courier Rates'

    name = fields.Char(string='Name')
    zone = fields.Char(string='Zone')
    rates = fields.Char(string='Rates')

    courier_rates_line_id = fields.One2many(
        'courier.rates.line', "courier_rates_id", string='Rates')


class Courier_Rates_Line(models.Model):
    _name = 'courier.rates.line'
    _despriction = 'Courier Rates Line'

    courier_rates_id = fields.Many2one('courier.rates')

    name = fields.Many2one('courier.zone', string='Name')
    rates = fields.Char(string='Rates')


class Courier_Cities(models.Model):
    _name = 'courier.cities'
    _despriction = 'Courier Cities'

    name = fields.Char(string='City Name', required=True)

    courier_cities_line_id = fields.One2many(
        'courier.cities.line', "courier_cities_id", string='City Matching Combinations')


class Courier_Cities_Lines(models.Model):
    _name = 'courier.cities.line'
    _despriction = 'Courier Cities Line'

    courier_cities_id = fields.Many2one('courier.cities')
    city_combination = fields.Char(string='Combination City Name')


class Courier_Provinces(models.Model):
    _name = 'courier.provinces'
    _despriction = 'Courier Provinces'

    name = fields.Char(string='Province Name', required=True)
    courier_Provinces_line_id = fields.One2many(
        'courier.provinces.line', "courier_Provinces_id", string='Select Cities For Province')


class Courier_Provinces_Lines(models.Model):
    _name = 'courier.provinces.line'
    _despriction = 'Courier Provinces Line'

    courier_Provinces_id = fields.Many2one('courier.provinces')
    city_ = fields.Many2one('courier.cities', string='Cities')


class Partner(models.Model):
    _inherit = 'res.partner'
    courier_group = fields.Many2one('courier.group', string='Assigned Courier')
    # courier_type = fields.Selection([('TCS','TCS'), ('Forrun','Forrun'),('Trax','Trax'),('LCS','LCS')], string='Select Courier')


# class SaleOrder(models.Model):
#     _inherit = 'sale.order'
#     courier_type_group = fields.Many2one(string='Assigned Courier Group', readonly = True , related = 'partner_id.courier_group')
#     courier_type = fields.Many2one('courier_model' , string='Select Courire')
#     zone = fields.Char(string = 'Zone')
#     courier_cn_no = fields.Char(string = 'CN NO')


#     @api.onchange('x_studio_city')
#     def get_zone(self):
#         for rec in self:
#             # get_city = self.env['courier.cities.line'].search([('city_combination','=',rec.x_studio_city)])
#             # # raise UserError(str(get_city))
#             # if get_city:
#             get_zone = self.env['courier.zone'].search([])
#             for zone in get_zone:
#                 for province in zone.courier_provinces:
#                     for province_line in province.courier_Provinces_line_id:
#                         for city in province_line.city_.courier_cities_line_id:
#                             for city_line in city:
#                                 if rec.x_studio_city == city_line.city_combination:
#                                     rec['zone'] = zone.name
#                                 # else:
#                                 #     rec['zone'] = 'Zone Not Found Check City Name or Combination'
#                             # else:
#                             #     raise UserError("Unable to assign ZONE!!! Following City not Exist in City Combinations" +' '+ str(rec.x_studio_city))


#     def get_barcode(self):
#         CN_No = self.courier_cn_no
#         for record in self:
#             record.courier_cn_no = CN_No;
#             # record.invoice_status = 'CN No Generated'
#             img = qrcode.make(record.courier_cn_no)
#             result = io.BytesIO()
#             img.save(result, format='PNG')
#             result.seek(0)
#             img_bytes = result.read()
#             base64_encoded_result_bytes = base64.b64encode(img_bytes)
#             record.x_studio_qr_code = base64_encoded_result_bytes

#             barcode = createBarcodeDrawing('Code128', value = str(record.courier_cn_no), barWidth = 0.05 * units.inch, fontSize = 30, humanReadable = True)
#             width = 600
#             drawing_width = width
#             barcode_scale = drawing_width / barcode.width
#             drawing_height = barcode.height * barcode_scale

#             drawing = Drawing(drawing_width, drawing_height)
#             drawing.scale(barcode_scale, barcode_scale)
#             drawing.add(barcode, name='barcode')
#             data_new = b64encode(renderPM.drawToString(drawing, fmt = 'PNG'))

#             record.x_studio_barcode = data_new


#     def get_sale_order(self):
#         for rec in self:
#             get_courier = self.env['courier_model'].search([('name','=',rec.courier_type.name)])
#             if get_courier:
#                 for _courier_ in get_courier:
#                     if _courier_.courier_type == 'Trax':
#                         url = _courier_.url

#                         HEADERS = {
#                             "Authorization": _courier_.authorization ,
#                         }
#                         BODY = {
#                             'service_type_id' :  1,
#                             "pickup_address_id": int(2433),
#                             "information_display": "1",
#                             "consignee_city_id": int(101),
#                             "consignee_name": str("Hamza Khan Khattak"),
#                             "consignee_address": str("ABS ka office"),
#                             "consignee_phone_number_1": str('0311-2391957'),
#                             "consignee_phone_number_2": " ",
#                             "consignee_email_address": str("Hamza.khattak.9678@gmail.com"),
#                             "order_id": " ",
#                             "item_product_type_id": int(12),
#                             "item_description": str("Peeli Sting"),
#                             "item_quantity": int(1),
#                             "item_insurance":int(0),
#                             "item_price": " ",
#                             "special_instructions" : " ",
#                             "same_day_timing_id": " ",
#                             "pickup_date": '2022-06-21',
#                             "estimated_weight": float(1.5),
#                             "shipping_mode_id":int(1),
#                             "amount": int(80),
#                             "payment_mode_id": int(1),
#                             "charges_mode_id": int(2),
#                             "open_box": " ",
#                             "pieces_quantity": " ",
#                             "shipper_reference_number_1": " ",
#                             "shipper_reference_number_2": " ",
#                             "shipper_reference_number_3": " ",
#                             "shipper_reference_number_4": " ",
#                             "shipper_reference_number_5": " "


#                         }
#                         try:
#                             response = requests.request("POST", url, headers=HEADERS ,data=json.dumps(BODY))
#                             raise UserError(str(response.text))

#                         except Exception as e:

#                             raise UserError(rec.name +"is not posted following is the exception "+ str(e))

#                     elif _courier_.courier_type == 'TCS':

#                         url = str(_courier_.url)

#                         payload = {

#                             "userName": str(_courier_.username),
#                             "password": str(_courier_.password),
#                             "costCenterCode": "1123",
#                             "consigneeName": "HamzaKhattak",
#                             "consigneeAddress": "abcKarachi",
#                             "consigneeMobNo": '03112391957',
#                             "consigneeEmail": 'abc@gmail.com',
#                             "originCityName": "karachi",
#                             "destinationCityName": "Lahore",
#                             "weight": 1,
#                             "pieces": 1,
#                             "codAmount": rec.amount_total,
#                             "customerReferenceNo": rec.courier_cn_no,
#                             "services": "O",
#                             "productDetails": "string",
#                             "fragile": "Yes",
#                             "remarks": "string",
#                             "insuranceValue": 1
#                         }


#                         headers = {
#                             'Content-Type': 'application/json',
#                             'X-IBM-Client-Id': str(_courier_.api_key),
#                         }
#                         try:
#                             response = requests.request("POST", url, headers=headers ,data=json.dumps(payload))
#                             Asir = str(response.text).split('Your generated CN is: ')[1]
#                             Chummi = str(Asir).split('}')[0]
#                             CN_No = str(Chummi).split('"')[0]

#                             # raise UserError(str(CN_No))


#                             rec.courier_cn_no = CN_No;


#                         except Exception as e:
#                             raise UserError(rec.name +"is not posted following is the exception "+ str(e))
#                         # raise UserError(get_courier.name +" "+ get_courier.authorization +" "+ get_courier.url)

#                     elif _courier_.courier_type == 'LCS':
#                         URL = str(_courier_.url)

#                         header = {
#                             "Content-Type": "application/json"
#                         }

#                         body = {
#                                 'api_key' : str(_courier_.api_key),
#                                 'api_password' : str(_courier_.password),
#                                 'booked_packet_weight' : "100",
#                                 'booked_packet_vol_weight_w' : 0,
#                                 'booked_packet_vol_weight_h' : 0,
#                                 'booked_packet_vol_weight_l': 0,
#                                 'booked_packet_no_piece' : 1,
#                                 'booked_packet_collect_amount' : "500",
#                                 'booked_packet_order_id': "Test123",
#                                 'origin_city': 789,
#                                 'destination_city': 789,
#                                 'shipment_id': 125,
#                                 'shipment_name_eng' : "Hamza Khattak",
#                                 'shipment_email' : "TEST@abc.vom",
#                                 'shipment_phone' : "03112391957",
#                                 'shipment_address': "Test House",
#                                 'consignment_name_eng' : "Allied",
#                                 'consignment_email': "Allied@ecom.com",
#                                 'consignment_phone' : "0321252125",
#                                 'consignment_phone_two' : " ",
#                                 'consignment_phone_three': " ",
#                                 'consignment_address': "VBrooks Chowrangi",
#                                 'special_instructions' : "Keep it safe",
#                                 'shipment_type' : " ",
#                                 'custom_data' : " ",
#                                 'return_address' : " "
#                         }

#                         response = requests.request("POST", URL, headers=header ,data=json.dumps(body))
#                         raise UserError(str(response.text))
#                         json_text = json.loads(response.text)
#                         # raise UserError(json_text)
#             else:
#                 raise UserError("Courier Assigned to Customer Not Found!!!")


# stock Picking Work

class StockPicking(models.Model):
    _inherit = 'stock.picking'
    courier_type_group = fields.Many2one(
        string='Assigned Courier Group', readonly=True, related='partner_id.courier_group')
    courier_type = fields.Many2one('courier_model', string='Select Courire')
    zone = fields.Char(string='Zone')
    courier_cn_no = fields.Char(string='CN NO')
    barcode = fields.Binary("Image")
    qr_code = fields.Binary("Image")
    city = fields.Char(string='City')
    ship_weight = fields.Float(string='Shipping Weight')
    # barcode = fields.Binary()

    # @api.multi
    def get_barcode_custom(self):
        cnno = self.get_sale_order()
        self.get_barcode()
        return cnno

    def do_print_airway_bill(self):
        self.write({'printed': True})
        return self.env.ref('courier_intergration.action_report_airway_bills').report_action(self)

    def get_barcode(self):
        CN_No = self.courier_cn_no
        for record in self:
            record.courier_cn_no = CN_No
            # record.invoice_status = 'CN No Generated'
            img = qrcode.make(record.courier_cn_no)
            result = io.BytesIO()
            img.save(result, format='PNG')
            result.seek(0)
            img_bytes = result.read()
            base64_encoded_result_bytes = base64.b64encode(img_bytes)
            record.qr_code = base64_encoded_result_bytes

            barcode = createBarcodeDrawing('Code128', value=str(
                record.courier_cn_no), barWidth=0.05 * units.inch, fontSize=30, humanReadable=True)
            width = 600
            drawing_width = width
            barcode_scale = drawing_width / barcode.width
            drawing_height = barcode.height * barcode_scale

            drawing = Drawing(drawing_width, drawing_height)
            drawing.scale(barcode_scale, barcode_scale)
            drawing.add(barcode, name='barcode')
            data_new = b64encode(renderPM.drawToString(drawing, fmt='PNG'))

            record.barcode = data_new
            # return CN_No

    def get_sale_order(self):
        for rec in self:

            get_courier = self.env['courier_model'].search(
                [('name', '=', rec.courier_type.name)])
            if get_courier:
                for _courier_ in get_courier:
                    if not rec.courier_cn_no:
                        if _courier_.courier_type == 'Trax':
                            url = _courier_.url

                            headers = {
                                "Authorization": _courier_.authorization,
                            }

                            city_url = 'https://sonic.pk/api/cities'

                            response = requests.request(
                                "GET", city_url, headers=headers)
                            print(str(response.text))

                            response_json = response.json()

                            city_id = 0
                            origin_city = 0
                            service_type = 0
                            for in_list_rec in response_json['cities']:
                                # print(str(rec['CityID']) +" "+ rec['CityName'])
                                if rec.partner_id.city.upper() == in_list_rec['name'].upper():
                                    city_id = in_list_rec['id']
                                    print(str(city_id))

                            print(city_id)
                            total = 0
                            get_sale_order = self.env['sale.order'].search(
                                [('name', '=', rec.origin)])
                            
                            email_trax = ' '
                            if rec.partner_id.email:
                                email_trax = rec.partner_id.email
                            else:
                                email_trax = 'info@alliedecoms.com'


                            for sale_order in get_sale_order:

                                if sale_order.x_studio_payment_mode == "Prepaid":
                                    total = 0
                                else:
                                    total = sale_order.amount_total
                                payload = {
                                    'service_type_id':  1,
                                    "pickup_address_id": int(_courier_.pickup_address_id),
                                    "information_display": 0,
                                    "consignee_city_id": int(city_id),
                                    "consignee_name": rec.partner_id.name,
                                    "consignee_address": rec.partner_id.street,
                                    "consignee_phone_number_1": rec.partner_id.phone,
                                    # "consignee_phone_number_2": " ",
                                    "consignee_email_address": email_trax,
                                    "order_id": sale_order.shopify_order_number,
                                    "item_product_type_id": 24,
                                    "item_description": 'Call Consignee Before Delivery. Order No: '+" "+str(rec.origin),
                                    "item_quantity": 2,
                                    "item_insurance": 0,
                                    # "item_price": " ",
                                    "pickup_date": date.today(),
                                    # "special_instructions" : " ",
                                    "estimated_weight": rec.ship_weight,
                                    "shipping_mode_id": 1,
                                    # "same_day_timing_id": " ",
                                    "amount": total,
                                    "payment_mode_id": 1,
                                    "charges_mode_id": 4,
                                    # "open_shipment": " ",
                                    # "pieces_quantity": " ",
                                    # "shipper_reference_number_1": " ",
                                    # "shipper_reference_number_2": " ",
                                    # "shipper_reference_number_3": " ",
                                    # "shipper_reference_number_4": " ",
                                    # "shipper_reference_number_5": " ",
                                }

                                try:

                                    response = requests.request(
                                        "POST", url, headers=headers, data=payload)
                                    JSON_REPONSE = json.loads(response.text)
                                    # return JSON_REPONSE['CNNO']
                                    if JSON_REPONSE['tracking_number']:
                                        rec['courier_cn_no'] = JSON_REPONSE['tracking_number']
                                        return "Posted"
                                    else:
                                        return str(response.text)

                                except Exception as Ex:
                                    return (str(Ex) + ' ' + str(response.text))

                        elif _courier_.courier_type == 'Call Courier':

                            url = str(_courier_.url)
                            get_sale_order = self.env['sale.order'].search(
                                [('name', '=', rec.origin)])

                            for sale_order in get_sale_order:
                                citylist_url = 'http://cod.callcourier.com.pk/API/CallCourier/GetCityListByService?serviceID=7'

                                response = requests.request(
                                    'GET', url=citylist_url)
                                # print(response.text)

                                response_json = response.json()
                                # print(response_json)
                                # city = "karachi"
                                city_id = 0
                                origin_city = 0
                                service_type = 0
                                for in_list_rec in response_json:

                                    # print(str(rec['CityID']) +" "+ rec['CityName'])
                                    if rec.partner_id.city.upper() == in_list_rec['CityName']:
                                        city_id = in_list_rec['CityID']

                                for in_list_rec_origin in response_json:
                                    # print(str(rec['CityID']) +" "+ rec['CityName'])
                                    if rec.x_studio_sender.city.upper() == in_list_rec_origin['CityName']:
                                        origin_city = in_list_rec_origin['CityID']

                                if sale_order.x_studio_payment_mode == 'Postpaid':
                                    service_type = 7
                                else:
                                    service_type = 1

                                if rec.partner_id.street:
                                    hold = rec.partner_id.street
                                    consignee_adress = hold.replace("#", " ")

                                shipper_area_id = 0
                                if rec.x_studio_sender.city == 'Karachi':
                                    
                                    shipper_area_id = 537
                                elif rec.x_studio_sender.city == 'Lahore':
                                    shipper_area_id = 1



                                if city_id:
                                    BODY = {
                                        # "loginId": "KHI-15580",
                                        "loginId": str(_courier_.username),
                                        "ShipperName": str(rec.x_studio_sender.name),
                                        "ShipperCellNo": str(rec.x_studio_sender.phone),
                                        "ShipperArea": str(shipper_area_id),
                                        "ShipperCity": str(origin_city),
                                        "OriginCity": str(origin_city),
                                        "ShipperAddress": str(rec.picking_type_id.warehouse_id.partner_id.name),
                                        "ShipperReturnAddress": "xyz",
                                        "ShipperLandLineNo": "12345678",
                                        "ShipperEmail": str(rec.x_studio_sender.email),

                                        "index": "1",
                                        "ConsigneeName": str(rec.partner_id.name),
                                        "ConsigneeRefNo": str(rec.origin),
                                        "ConsigneeCellNo": str(rec.partner_id.phone),
                                        "Address": str(consignee_adress),
                                        "DestCityId": str(city_id),
                                        "ServiceTypeId": str(service_type),
                                        # "ServiceTypeId": "1",
                                        "Pcs": "01",
                                        "Weight": str(rec.ship_weight),
                                        "Description": "Order Fulfilled by Allied E-Commerce Solution",
                                        "SelOrigin": "Domestic",
                                        "CodAmount": str(sale_order.amount_total),
                                        "SpecialHandling": "false",
                                        "MyBoxId": "My Box ID",
                                        "Holiday": "false",
                                        "remarks": "Bulk Test Remarks 1",

                                    }
                                else:
                                    # raise UserError("b")
                                    return "Check Destination/Consignee City" + str(rec.partner_id.city)

                                try:
                                    # FINAL_DUMY_URL = 'https://cod.callcourier.com.pk/api/CallCourier/SaveBooking?loginId=test-0001&ConsigneeName=Sabeeh&ConsigneeRefNo=5627087636&ConsigneeCellNo=03004344328&Address=Sher+Shah+Block+New+Garden&Origin=Lahore&DestCityId=18&ServiceTypeId=7&Pcs=01&Weight=01&Description=Test%20Description&SelOrigin=Domestic&CodAmount=1&SpecialHandling=false&MyBoxId=1%20My%20Box%20ID&Holiday=false&remarks=Test%20Remarks&ShipperName=ShipperName&ShipperCellNo=03004344328&ShipperArea=1&ShipperCity=1&ShipperAddress=kks&ShipperLandLineNo=34544343&ShipperEmail=sabeeh@gmail.com'
                                    FINAL_DUMY_URL = "http://cod.callcourier.com.pk/api/CallCourier/SaveBooking?loginId="+BODY['loginId']+"&ConsigneeName="+BODY['ConsigneeName']+"&ConsigneeRefNo="+BODY['ConsigneeRefNo']+"&ConsigneeCellNo="+BODY['ConsigneeCellNo']+"&Address="+BODY['Address']+"&Origin="+BODY['OriginCity']+"&DestCityId="+BODY['DestCityId']+"&ServiceTypeId="+BODY['ServiceTypeId']+"&Pcs="+BODY['Pcs']+"&Weight="+BODY['Weight']+"&Description="+BODY[
                                        'Description']+"&SelOrigin=Domestic&CodAmount="+BODY['CodAmount']+"&SpecialHandling=false&MyBoxId=1%20My%20Box%20ID&Holiday=false&remarks="+BODY['remarks']+"%20Remarks&ShipperName="+BODY['ShipperName']+"&ShipperCellNo="+BODY['ShipperCellNo']+"&ShipperArea="+BODY['ShipperArea']+"&ShipperCity="+BODY['ShipperCity']+"&ShipperAddress="+BODY['ShipperAddress']+"&ShipperLandLineNo=34544343&ShipperEmail="+BODY['ShipperEmail']+""
                                    response = requests.request(
                                        'GET', url=FINAL_DUMY_URL)
                                    # response = requests.request("POST", url= url ,data=json.dumps(BODY))
                                    # raise UserError(response.text)

                                    JSON_REPONSE = json.loads(response.text)
                                    # return JSON_REPONSE['CNNO']
                                    if JSON_REPONSE['CNNO']:
                                        rec['courier_cn_no'] = JSON_REPONSE['CNNO']
                                        return "Posted"
                                        # raise UserError('Posted')
                                    else:
                                        # raise UserError("CN NO not generated!!! Check COD it can't be Zero" + str(response.text))
                                        return "CN NO not generated!!! Check COD it can't be Zero" + str(response.text)

                                except Exception as Ex:
                                    # raise UserError(str(Ex))
                                    return (str(Ex))
                                    # raise UserError(str(Ex))
                        elif _courier_.courier_type == 'TCS':
                            sale_order = self.env['sale.order'].search(
                                [('name', '=', rec.origin)])
                            if sale_order:
                                for rec_tcs in sale_order:
                                    cost_centr_code = "0"
                                    total = "0"
                                    url = str(_courier_.url)
                                    if rec.picking_type_id.warehouse_id.partner_id.city == 'Lahore':
                                        cost_centr_code = '1122'
                                    elif rec.picking_type_id.warehouse_id.partner_id.city == 'Karachi':
                                        cost_centr_code = '112222'

                                    if rec_tcs.x_studio_payment_mode == "Prepaid":
                                        total = 0
                                    else:
                                        total = rec_tcs.amount_total
                                    email_tcs = ' '
                                    if rec.partner_id.email:
                                        email_tcs = rec.partner_id.email
                                    else:
                                        email_tcs = 'info@alliedecoms.com'


                                    payload = {

                                        "userName": str(_courier_.username),
                                        "password": str(_courier_.password),
                                        "costCenterCode": str(_courier_.cost_center_id),
                                        # "costCenterCode" : str("337236"),
                                        "consigneeName": str(rec.partner_id.name),
                                        "consigneeAddress": str(rec.partner_id.street),
                                        "consigneeMobNo": str(rec.partner_id.phone),
                                        "consigneeEmail": str(email_tcs),
                                        "originCityName": str(rec.picking_type_id.warehouse_id.partner_id.city),
                                        "destinationCityName": str(rec.partner_id.city),
                                        "weight": rec.ship_weight,
                                        "pieces": 1,
                                        "codAmount": total,
                                        "customerReferenceNo": str(rec_tcs.shopify_order_number),
                                        "services": "O",
                                        "productDetails": str(rec_tcs.x_item_details),
                                        "fragile": "Yes",
                                        "remarks": "string",
                                        "insuranceValue": 1
                                    }

                                    headers = {
                                        'Content-Type': 'application/json',
                                        'X-IBM-Client-Id': str(_courier_.api_key),
                                    }
                                    try:
                                        response = requests.request(
                                            "POST", url, headers=headers, data=json.dumps(payload))
                                        # raise UserError(str(response.text))
                                        # return str(response.text)
                                        json_response = json.loads(
                                            response.text)
                                        print(
                                            json_response['bookingReply']["result"])
                                        if json_response['bookingReply']["result"]:
                                            Asir = str(json_response['bookingReply']["result"]).split(
                                                'Your generated CN is: ')[1]
                                            # Asir = str(response.text).split('Your generated CN is: ')[1]
                                            # Chummi = str(Asir).split('}')[0]
                                            CN_No = Asir

                                            # raise UserError(str(response.text))

                                            rec.courier_cn_no = CN_No

                                            return "Posted"
                                        else:
                                            return str(json_response)

                                    except Exception as e:
                                        return (str(e) + " is not posted following is the exception " + str(response.text))

                                    # raise UserError(get_courier.name +" "+ get_courier.authorization +" "+ get_courier.url)

                            else:
                                return "sale order Not found"

                        elif _courier_.courier_type == 'Daraz':
                            if rec.x_studio_daraz_tracking_no:
                                rec.courier_cn_no = rec.x_studio_daraz_tracking_no

                                return "Posted"

                            else:
                                return "Daraz Tracking Not Found"

                        elif _courier_.courier_type == 'LCS':
                            sale_order = self.env['sale.order'].search(
                                [('name', '=', rec.origin)])
                            if sale_order:
                                URL = str(_courier_.url)

                                production_url = 'http://new.leopardscod.com/webservice/bookPacket/format/json?'
                                get_cities = 'http://new.leopardscod.com/webservice/getAllCities/format/json/'

                                headers = {
                                    "Content-Type": "application/json"
                                }

                                payload_Cities = {
                                    "api_key": str(_courier_.api_key),
                                    "api_password": str(_courier_.password),

                                }

                                response = requests.request(
                                    "POST", get_cities, headers=headers, data=json.dumps(payload_Cities))
                                json_text = json.loads(response.text)

                                print(response.text)
                                city = "Abbottabad"
                                city_id = 0
                                origin_city = 0
                                service_type = 0
                                for in_list_rec in json_text['city_list']:
                                    # print(str(rec['CityID']) +" "+ rec['CityName'])
                                    if rec.partner_id.city.upper() == in_list_rec['name'].upper():
                                        city_id = in_list_rec['id']
                                        print(str(city_id))

                                print(city_id)

                                total = 0
                                if sale_order.x_studio_payment_mode == "Prepaid":
                                    total = 0
                                else:
                                    total = sale_order.amount_total
                                email = " "
                                if rec.partner_id.email:
                                    email = rec.partner_id.email
                                else:
                                    email = 'info@alliedecoms.com'


                                Payload = {
                                    "api_key": str(_courier_.api_key),
                                    "api_password": str(_courier_.password),
                                    "booked_packet_weight": str(rec.ship_weight),
                                    "booked_packet_vol_weight_w": "",
                                    "booked_packet_vol_weight_h": "",
                                    "booked_packet_vol_weight_l": "",
                                    "booked_packet_no_piece": "1",
                                    "booked_packet_collect_amount": str(total),
                                    "booked_packet_order_id": str(sale_order.shopify_order_number),
                                    "origin_city": "self",
                                    "destination_city": str(city_id),
                                    "shipment_name_eng": "self",
                                    "shipment_email": "info@alliedecoms.com",
                                    "shipment_phone": "self",
                                    "shipment_address": "self",
                                    "consignment_name_eng": str(rec.partner_id.name),
                                    "consignment_email": str(email),
                                    "consignment_phone": str(rec.partner_id.phone),
                                    "consignment_phone_two": "",
                                    "consignment_phone_three": "",
                                    "consignment_address": str(rec.partner_id.street),
                                    "special_instructions": "Call Customer before delivery, Please do not pay more than the invoice value."
                                }
                                try:
                                    response2 = requests.request(
                                        "POST", URL, headers=headers, data=json.dumps(Payload))

                                    json_text = json.loads(response2.text)
                                    if json_text['track_number']:
                                        rec.courier_cn_no = json_text['track_number']
                                        return "Posted"
                                    else:
                                        return "Error While Posting", str(json_text)
                                except Exception as e:
                                    return (str(e) + " is not posted following is the exception " + str(response.text))
                        # bilal 
                        elif _courier_.courier_type == 'self_pickup':
                            rec['courier_cn_no'] = self.env['ir.sequence'].next_by_code('self_pcikup_seq')
                            # raise UserError("Self Pickup")
                    else:
                        return "CN no already posted..."
            else:
                return "Courier Assigned to Customer Not Found!!!"

    @api.onchange('city')
    def get_zone(self):
        for rec in self:
            # get_city = self.env['courier.cities.line'].search([('city_combination','=',rec.x_studio_city)])
            # # raise UserError(str(get_city))
            # if get_city:
            get_zone = self.env['courier.zone'].search([])
            for zone in get_zone:
                for province in zone.courier_provinces:
                    for province_line in province.courier_Provinces_line_id:
                        for city in province_line.city_.courier_cities_line_id:
                            for city_line in city:
                                if rec.city == city_line.city_combination:
                                    rec['zone'] = zone.name
                                # else:
                                #     rec['zone'] = 'Zone Not Found Check City Name or Combination'
                            # else:
                            #     raise UserError("Unable to assign ZONE!!! Following City not Exist in City Combinations" +' '+ str(rec.x_studio_city))


# Khattak Work

    # def get_sale_order(self):
    #     for rec in self:

    #         get_courier = self.env['courier_model'].search([('name','=',rec.courier_type.name)])
    #         if get_courier:
    #             for _courier_ in get_courier:
    #                 if _courier_.courier_type == 'Trax':
    #                     url = _courier_.url

    #                     HEADERS = {
    #                         "Authorization": _courier_.authorization ,
    #                     }
    #                     BODY = {
    #                         'service_type_id' :  1,
    #                         "pickup_address_id": int(2433),
    #                         "information_display": "1",
    #                         "consignee_city_id": int(101),
    #                         "consignee_name": str("Hamza Khan Khattak"),
    #                         "consignee_address": str("ABS ka office"),
    #                         "consignee_phone_number_1": str('0311-2391957'),
    #                         "consignee_phone_number_2": " ",
    #                         "consignee_email_address": str("Hamza.khattak.9678@gmail.com"),
    #                         "order_id": " ",
    #                         "item_product_type_id": int(12),
    #                         "item_description": str("Peeli Sting"),
    #                         "item_quantity": int(1),
    #                         "item_insurance":int(0),
    #                         "item_price": " ",
    #                         "special_instructions" : " ",
    #                         "same_day_timing_id": " ",
    #                         "pickup_date": '2022-06-21',
    #                         "estimated_weight": float(1.5),
    #                         "shipping_mode_id":int(1),
    #                         "amount": int(80),
    #                         "payment_mode_id": int(1),
    #                         "charges_mode_id": int(2),
    #                         "open_box": " ",
    #                         "pieces_quantity": " ",
    #                         "shipper_reference_number_1": " ",
    #                         "shipper_reference_number_2": " ",
    #                         "shipper_reference_number_3": " ",
    #                         "shipper_reference_number_4": " ",
    #                         "shipper_reference_number_5": " "

    #                     }
    #                     try:
    #                         response = requests.request("POST", url, headers=HEADERS ,data=json.dumps(BODY))
    #                         raise UserError(str(response.text))

    #                     except Exception as e:

    #                         raise UserError(rec.name +"is not posted following is the exception "+ str(e))

    #                 elif _courier_.courier_type == 'Call Courier':

    #                     url = str(_courier_.url)
    #                     get_sale_order = self.env['sale.order'].search([('name','=',rec.origin)])

    #                     for sale_order in get_sale_order:
    #                         citylist_url = 'http://cod.callcourier.com.pk/API/CallCourier/GetCityListByService?serviceID=7'

    #                         response = requests.request('GET' , url = citylist_url)
    #                         # print(response.text)

    #                         response_json = response.json()
    #                         # print(response_json)
    #                         # city = "karachi"
    #                         city_id = 0
    #                         for in_list_rec in response_json:
    #                             # print(str(rec['CityID']) +" "+ rec['CityName'])
    #                             if rec.partner_id.city.upper() == in_list_rec['CityName']:
    #                                 city_id = in_list_rec['CityID']

    #                         if city_id:
    #                             BODY = {
    #                                 "loginId": str(_courier_.username),
    #                                 "ShipperName": str(rec.x_studio_sender.name),
    #                                 "ShipperCellNo": str(rec.x_studio_sender.name),
    #                                 "ShipperArea": "1",
    #                                 "ShipperCity": "1",
    #                                 "ShipperAddress": str(rec.x_studio_sender.street),
    #                                 "ShipperReturnAddress": str(rec.x_studio_sender.street),
    #                                 "ShipperLandLineNo": "12345678",
    #                                 "ShipperEmail": "Allied_Ecoms@gmail.com",

    #                                 "index": "1",
    #                                 "ConsigneeName": str(rec.partner_id.name),
    #                                 "ConsigneeRefNo": str(rec.partner_id.name),
    #                                 "ConsigneeCellNo": str(rec.partner_id.phone),
    #                                 "Address": str(rec.partner_id.street),
    #                                 "DestCityId": str(city_id),
    #                                 "ServiceTypeId": "7",
    #                                 "Pcs": "01",
    #                                 "Weight": str(rec.ship_weight),
    #                                 "Description": "Handle With Care",
    #                                 "SelOrigin": "Domestic",
    #                                 "CodAmount": sale_order.amount_total,
    #                                 "SpecialHandling": "false",
    #                                 "MyBoxId": "My Box ID",
    #                                 "Holiday": "false",
    #                                 "remarks": "Bulk Test Remarks 1"
    #                             }
    #                         else:
    #                             raise UserError("Please Make sure to assign correct city "+ str(rec.partner_id.city))
    #                         try:
    #                             # FINAL_DUMY_URL = 'https://cod.callcourier.com.pk/api/CallCourier/SaveBooking?loginId=test-0001&ConsigneeName=Sabeeh&ConsigneeRefNo=5627087636&ConsigneeCellNo=03004344328&Address=Sher+Shah+Block+New+Garden&Origin=Lahore&DestCityId=18&ServiceTypeId=7&Pcs=01&Weight=01&Description=Test%20Description&SelOrigin=Domestic&CodAmount=1&SpecialHandling=false&MyBoxId=1%20My%20Box%20ID&Holiday=false&remarks=Test%20Remarks&ShipperName=ShipperName&ShipperCellNo=03004344328&ShipperArea=1&ShipperCity=1&ShipperAddress=kks&ShipperLandLineNo=34544343&ShipperEmail=sabeeh@gmail.com'
    #                             FINAL_DUMY_URL = "http://cod.callcourier.com.pk/api/CallCourier/SaveBooking?loginId="+BODY['loginId']+"&ConsigneeName="+BODY['ConsigneeName']+"&ConsigneeRefNo="+BODY['ConsigneeRefNo']+"&ConsigneeCellNo="+BODY['ConsigneeCellNo']+"&Address="+BODY['Address']+"&Origin=Lahore&DestCityId="+BODY['DestCityId']+"&ServiceTypeId=7&Pcs="+BODY['Pcs']+"&Weight="+BODY['Weight']+"&Description="+BODY['Description']+"&SelOrigin=Domestic&CodAmount="+str(BODY['CodAmount'])+"&SpecialHandling="+BODY['SpecialHandling']+"&MyBoxId=1%20My%20Box%20ID&Holiday=false&remarks="+BODY['remarks']+"%20Remarks&ShipperName="+BODY['ShipperName']+"&ShipperCellNo="+BODY['ShipperCellNo']+"&ShipperArea=1&ShipperCity=1&ShipperAddress=kks&ShipperLandLineNo=34544343&ShipperEmail="+BODY['ShipperEmail']+""
    #                             response = requests.request('GET' , url = FINAL_DUMY_URL)
    #                             # raise UserError(response.text)
    #                             response_json = response.json()
    #                             if response_json['CNNO']:
    #                                 rec['courier_cn_no'] = response_json["CNNO"]
    #                             else:
    #                                 raise UserError("CN NO not generated!!! Check COD it can't be Zero")

    #                         except Exception as Ex:
    #                             raise UserError(str(Ex))
    #                 elif _courier_.courier_type == 'TCS':
    #                     sale_order = self.env['sale.order'].search([('name','=',rec.origin)])
    #                     if sale_order:
    #                         for rec_tcs in sale_order:
    #                             cost_centr_code = "0"
    #                             url = str(_courier_.url)
    #                             if rec.picking_type_id.warehouse_id.partner_id.city == 'Lahore':
    #                                 cost_centr_code = '1122'
    #                             elif rec.picking_type_id.warehouse_id.partner_id.city == 'Karachi':
    #                                 cost_centr_code = '112222'
    #                             payload = {

    #                                 "userName": str(_courier_.username),
    #                                 "password": str(_courier_.password),
    #                                 "costCenterCode": str(cost_centr_code),
    #                                 "consigneeName": str(rec.partner_id.name),
    #                                 "consigneeAddress": str(rec.partner_id.street),
    #                                 "consigneeMobNo": str(rec.partner_id.phone),
    #                                 "consigneeEmail": str(rec.partner_id.email),
    #                                 "originCityName": str(rec.picking_type_id.warehouse_id.partner_id.city),
    #                                 "destinationCityName": str(rec.partner_id.city),
    #                                 "weight": rec.ship_weight,
    #                                 "pieces": 1,
    #                                 "codAmount": rec_tcs.amount_total,
    #                                 "customerReferenceNo": rec.origin,
    #                                 "services": "O",
    #                                 "productDetails": "string",
    #                                 "fragile": "Yes",
    #                                 "remarks": "string",
    #                                 "insuranceValue": 1
    #                             }

    #                             headers = {
    #                                 'Content-Type': 'application/json',
    #                                 'X-IBM-Client-Id': str(_courier_.api_key),
    #                             }
    #                             try:
    #                                 response = requests.request("POST", url, headers=headers ,data=json.dumps(payload))
    #                                 # raise UserError(str(response.text))
    #                                 json_response = json.loads(response.text)
    #                                 print(json_response['bookingReply']["result"])
    #                                 Asir = str(json_response['bookingReply']["result"]).split('Your generated CN is: ')[1]
    #                                 # Asir = str(response.text).split('Your generated CN is: ')[1]
    #                                 # Chummi = str(Asir).split('}')[0]
    #                                 CN_No = Asir

    #                                 # raise UserError(str(response.text))

    #                                 rec.courier_cn_no = CN_No

    #                             except Exception as e:
    #                                 raise UserError(rec.name + " is not posted following is the exception "+ str(e))

    #                             # raise UserError(get_courier.name +" "+ get_courier.authorization +" "+ get_courier.url)

    #                     else:
    #                         raise UserError("sale order Not found")

    #                 elif _courier_.courier_type == 'LCS':
    #                     URL = str(_courier_.url)

    #                     header = {
    #                         "Content-Type": "application/json"
    #                     }
    #                     # total_quantity = 0
    #                     sale_order_LCS = self.env['sale.order'].search([('name','=',rec.origin)])
    #                     # for Sale_Order_LCS in sale_order_LCS:
    #                     #     for Sale_Order_LCS_Line in Sale_Order_LCS.order_line:
    #                     #         total_quantity += Sale_Order_LCS_Line.product_uom_qty

    #                     try:
    #                         body = {
    #                                 'api_key' : str(_courier_.api_key),
    #                                 'api_password' : str(_courier_.password),
    #                                 'booked_packet_weight' : "100",
    #                                 'booked_packet_vol_weight_w' : 0,
    #                                 'booked_packet_vol_weight_h' : 0,
    #                                 'booked_packet_vol_weight_l': 0,
    #                                 'booked_packet_no_piece' : str(rec.x_studio_total_done_qty),
    #                                 'booked_packet_collect_amount' : str(sale_order_LCS.amount_total),
    #                                 'booked_packet_order_id': "Test123",
    #                                 'origin_city': 789,
    #                                 'destination_city': 789,
    #                                 'shipment_id': str(sale_order_LCS.name),
    #                                 'shipment_name_eng' : str(rec.partner_id.name),
    #                                 'shipment_email' : str(rec.partner_id.email),
    #                                 'shipment_phone' : str(rec.partner_id.phone),
    #                                 'shipment_address': str(rec.partner_id.street),
    #                                 'consignment_name_eng' : str(rec.x_studio_sender.name),
    #                                 'consignment_email': str(rec.x_studio_sender.email) if str(rec.x_studio_sender.email) else "allied@gmail.com",
    #                                 'consignment_phone' : (rec.x_studio_sender.phone) if (rec.x_studio_sender.phone) else '31229789484',
    #                                 'consignment_phone_two' : "",
    #                                 'consignment_phone_three': "",
    #                                 'consignment_address': str(rec.x_studio_sender.street),
    #                                 'special_instructions' : "Keep it safe",
    #                                 'shipment_type' : "",
    #                                 'custom_data' : "",
    #                                 'return_address' : ""
    #                         }

    #                         response = requests.request("POST", URL, headers=header ,data=json.dumps(body))
    #                         raise UserError(str(response.text))
    #                         json_text = json.loads(response.text)
    #                         # raise UserError(str(response.text))
    #                         # rec.courier_cn_no = json_text['track_number']
    #                     except Exception as Ex:
    #                         raise UserError(str(Ex))
    #                     # raise UserError(json_text)
    #         else:
    #             raise UserError("Courier Assigned to Customer Not Found!!!")
    #          def get_sale_order(self):
    #     for rec in self:

    #         get_courier = self.env['courier_model'].search([('name','=',rec.courier_type.name)])
    #         if get_courier:
    #             for _courier_ in get_courier:
    #                 if _courier_.courier_type == 'Trax':
    #                     url = _courier_.url

    #                     HEADERS = {
    #                         "Authorization": _courier_.authorization ,
    #                     }
    #                     BODY = {
    #                         'service_type_id' :  1,
    #                         "pickup_address_id": int(2433),
    #                         "information_display": "1",
    #                         "consignee_city_id": int(101),
    #                         "consignee_name": str("Hamza Khan Khattak"),
    #                         "consignee_address": str("ABS ka office"),
    #                         "consignee_phone_number_1": str('0311-2391957'),
    #                         "consignee_phone_number_2": " ",
    #                         "consignee_email_address": str("Hamza.khattak.9678@gmail.com"),
    #                         "order_id": " ",
    #                         "item_product_type_id": int(12),
    #                         "item_description": str("Peeli Sting"),
    #                         "item_quantity": int(1),
    #                         "item_insurance":int(0),
    #                         "item_price": " ",
    #                         "special_instructions" : " ",
    #                         "same_day_timing_id": " ",
    #                         "pickup_date": '2022-06-21',
    #                         "estimated_weight": float(1.5),
    #                         "shipping_mode_id":int(1),
    #                         "amount": int(80),
    #                         "payment_mode_id": int(1),
    #                         "charges_mode_id": int(2),
    #                         "open_box": " ",
    #                         "pieces_quantity": " ",
    #                         "shipper_reference_number_1": " ",
    #                         "shipper_reference_number_2": " ",
    #                         "shipper_reference_number_3": " ",
    #                         "shipper_reference_number_4": " ",
    #                         "shipper_reference_number_5": " "

    #                     }
    #                     try:
    #                         response = requests.request("POST", url, headers=HEADERS ,data=json.dumps(BODY))
    #                         raise UserError(str(response.text))

    #                     except Exception as e:

    #                         raise UserError(rec.name +"is not posted following is the exception "+ str(e))

    #                 elif _courier_.courier_type == 'Call Courier':

    #                     url = str(_courier_.url)
    #                     get_sale_order = self.env['sale.order'].search([('name','=',rec.origin)])

    #                     for sale_order in get_sale_order:
    #                         citylist_url = 'http://cod.callcourier.com.pk/API/CallCourier/GetCityListByService?serviceID=7'

    #                         response = requests.request('GET' , url = citylist_url)
    #                         # print(response.text)

    #                         response_json = response.json()
    #                         # print(response_json)
    #                         # city = "karachi"
    #                         city_id = 0
    #                         for in_list_rec in response_json:
    #                             # print(str(rec['CityID']) +" "+ rec['CityName'])
    #                             if rec.partner_id.city.upper() == in_list_rec['CityName']:
    #                                 city_id = in_list_rec['CityID']

    #                         if city_id:
    #                             BODY = {
    #                                 "loginId": str(_courier_.username),
    #                                 "ShipperName": str(rec.x_studio_sender.name),
    #                                 "ShipperCellNo": str(rec.x_studio_sender.name),
    #                                 "ShipperArea": "1",
    #                                 "ShipperCity": "1",
    #                                 "ShipperAddress": str(rec.x_studio_sender.street),
    #                                 "ShipperReturnAddress": str(rec.x_studio_sender.street),
    #                                 "ShipperLandLineNo": "12345678",
    #                                 "ShipperEmail": "Allied_Ecoms@gmail.com",

    #                                 "index": "1",
    #                                 "ConsigneeName": str(rec.partner_id.name),
    #                                 "ConsigneeRefNo": str(rec.partner_id.name),
    #                                 "ConsigneeCellNo": str(rec.partner_id.phone),
    #                                 "Address": str(rec.partner_id.street),
    #                                 "DestCityId": str(city_id),
    #                                 "ServiceTypeId": "7",
    #                                 "Pcs": "01",
    #                                 "Weight": str(rec.ship_weight),
    #                                 "Description": "Handle With Care",
    #                                 "SelOrigin": "Domestic",
    #                                 "CodAmount": sale_order.amount_total,
    #                                 "SpecialHandling": "false",
    #                                 "MyBoxId": "My Box ID",
    #                                 "Holiday": "false",
    #                                 "remarks": "Bulk Test Remarks 1"
    #                             }
    #                         else:
    #                             raise UserError("Please Make sure to assign correct city "+ str(rec.partner_id.city))
    #                         try:
    #                             # FINAL_DUMY_URL = 'https://cod.callcourier.com.pk/api/CallCourier/SaveBooking?loginId=test-0001&ConsigneeName=Sabeeh&ConsigneeRefNo=5627087636&ConsigneeCellNo=03004344328&Address=Sher+Shah+Block+New+Garden&Origin=Lahore&DestCityId=18&ServiceTypeId=7&Pcs=01&Weight=01&Description=Test%20Description&SelOrigin=Domestic&CodAmount=1&SpecialHandling=false&MyBoxId=1%20My%20Box%20ID&Holiday=false&remarks=Test%20Remarks&ShipperName=ShipperName&ShipperCellNo=03004344328&ShipperArea=1&ShipperCity=1&ShipperAddress=kks&ShipperLandLineNo=34544343&ShipperEmail=sabeeh@gmail.com'
    #                             FINAL_DUMY_URL = "http://cod.callcourier.com.pk/api/CallCourier/SaveBooking?loginId="+BODY['loginId']+"&ConsigneeName="+BODY['ConsigneeName']+"&ConsigneeRefNo="+BODY['ConsigneeRefNo']+"&ConsigneeCellNo="+BODY['ConsigneeCellNo']+"&Address="+BODY['Address']+"&Origin=Lahore&DestCityId="+BODY['DestCityId']+"&ServiceTypeId=7&Pcs="+BODY['Pcs']+"&Weight="+BODY['Weight']+"&Description="+BODY['Description']+"&SelOrigin=Domestic&CodAmount="+str(BODY['CodAmount'])+"&SpecialHandling="+BODY['SpecialHandling']+"&MyBoxId=1%20My%20Box%20ID&Holiday=false&remarks="+BODY['remarks']+"%20Remarks&ShipperName="+BODY['ShipperName']+"&ShipperCellNo="+BODY['ShipperCellNo']+"&ShipperArea=1&ShipperCity=1&ShipperAddress=kks&ShipperLandLineNo=34544343&ShipperEmail="+BODY['ShipperEmail']+""
    #                             response = requests.request('GET' , url = FINAL_DUMY_URL)
    #                             # raise UserError(response.text)
    #                             response_json = response.json()
    #                             if response_json['CNNO']:
    #                                 rec['courier_cn_no'] = response_json["CNNO"]
    #                             else:
    #                                 raise UserError("CN NO not generated!!! Check COD it can't be Zero")

    #                         except Exception as Ex:
    #                             raise UserError(str(Ex))
    #                 elif _courier_.courier_type == 'TCS':
    #                     sale_order = self.env['sale.order'].search([('name','=',rec.origin)])
    #                     if sale_order:
    #                         for rec_tcs in sale_order:
    #                             cost_centr_code = "0"
    #                             url = str(_courier_.url)
    #                             if rec.picking_type_id.warehouse_id.partner_id.city == 'Lahore':
    #                                 cost_centr_code = '1122'
    #                             elif rec.picking_type_id.warehouse_id.partner_id.city == 'Karachi':
    #                                 cost_centr_code = '112222'
    #                             payload = {

    #                                 "userName": str(_courier_.username),
    #                                 "password": str(_courier_.password),
    #                                 "costCenterCode": str(cost_centr_code),
    #                                 "consigneeName": str(rec.partner_id.name),
    #                                 "consigneeAddress": str(rec.partner_id.street),
    #                                 "consigneeMobNo": str(rec.partner_id.phone),
    #                                 "consigneeEmail": str(rec.partner_id.email),
    #                                 "originCityName": str(rec.picking_type_id.warehouse_id.partner_id.city),
    #                                 "destinationCityName": str(rec.partner_id.city),
    #                                 "weight": rec.ship_weight,
    #                                 "pieces": 1,
    #                                 "codAmount": rec_tcs.amount_total,
    #                                 "customerReferenceNo": rec.origin,
    #                                 "services": "O",
    #                                 "productDetails": "string",
    #                                 "fragile": "Yes",
    #                                 "remarks": "string",
    #                                 "insuranceValue": 1
    #                             }

    #                             headers = {
    #                                 'Content-Type': 'application/json',
    #                                 'X-IBM-Client-Id': str(_courier_.api_key),
    #                             }
    #                             try:
    #                                 response = requests.request("POST", url, headers=headers ,data=json.dumps(payload))
    #                                 # raise UserError(str(response.text))
    #                                 json_response = json.loads(response.text)
    #                                 print(json_response['bookingReply']["result"])
    #                                 Asir = str(json_response['bookingReply']["result"]).split('Your generated CN is: ')[1]
    #                                 # Asir = str(response.text).split('Your generated CN is: ')[1]
    #                                 # Chummi = str(Asir).split('}')[0]
    #                                 CN_No = Asir

    #                                 # raise UserError(str(response.text))

    #                                 rec.courier_cn_no = CN_No

    #                             except Exception as e:
    #                                 raise UserError(rec.name + " is not posted following is the exception "+ str(e))

    #                             # raise UserError(get_courier.name +" "+ get_courier.authorization +" "+ get_courier.url)

    #                     else:
    #                         raise UserError("sale order Not found")

    #                 elif _courier_.courier_type == 'LCS':
    #                     URL = str(_courier_.url)

    #                     header = {
    #                         "Content-Type": "application/json"
    #                     }
    #                     # total_quantity = 0
    #                     sale_order_LCS = self.env['sale.order'].search([('name','=',rec.origin)])
    #                     # for Sale_Order_LCS in sale_order_LCS:
    #                     #     for Sale_Order_LCS_Line in Sale_Order_LCS.order_line:
    #                     #         total_quantity += Sale_Order_LCS_Line.product_uom_qty

    #                     try:
    #                         body = {
    #                                 'api_key' : str(_courier_.api_key),
    #                                 'api_password' : str(_courier_.password),
    #                                 'booked_packet_weight' : "100",
    #                                 'booked_packet_vol_weight_w' : 0,
    #                                 'booked_packet_vol_weight_h' : 0,
    #                                 'booked_packet_vol_weight_l': 0,
    #                                 'booked_packet_no_piece' : str(rec.x_studio_total_done_qty),
    #                                 'booked_packet_collect_amount' : str(sale_order_LCS.amount_total),
    #                                 'booked_packet_order_id': "Test123",
    #                                 'origin_city': 789,
    #                                 'destination_city': 789,
    #                                 'shipment_id': str(sale_order_LCS.name),
    #                                 'shipment_name_eng' : str(rec.partner_id.name),
    #                                 'shipment_email' : str(rec.partner_id.email),
    #                                 'shipment_phone' : str(rec.partner_id.phone),
    #                                 'shipment_address': str(rec.partner_id.street),
    #                                 'consignment_name_eng' : str(rec.x_studio_sender.name),
    #                                 'consignment_email': str(rec.x_studio_sender.email) if str(rec.x_studio_sender.email) else "allied@gmail.com",
    #                                 'consignment_phone' : (rec.x_studio_sender.phone) if (rec.x_studio_sender.phone) else '31229789484',
    #                                 'consignment_phone_two' : "",
    #                                 'consignment_phone_three': "",
    #                                 'consignment_address': str(rec.x_studio_sender.street),
    #                                 'special_instructions' : "Keep it safe",
    #                                 'shipment_type' : "",
    #                                 'custom_data' : "",
    #                                 'return_address' : ""
    #                         }

    #                         response = requests.request("POST", URL, headers=header ,data=json.dumps(body))
    #                         raise UserError(str(response.text))
    #                         json_text = json.loads(response.text)
    #                         # raise UserError(str(response.text))
    #                         # rec.courier_cn_no = json_text['track_number']
    #                     except Exception as Ex:
    #                         raise UserError(str(Ex))
    #                     # raise UserError(json_text)
    #         else:
    #             raise UserError("Courier Assigned to Customer Not Found!!!")
