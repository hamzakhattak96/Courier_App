{
    'name': 'Courier Intergration API',
    'version': '15.0.1.0.0',
    'category': 'Sales',
    'sequence': 1,
    'author': 'Hamza Khattak/ Bilal',
    'depends': ['sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/courier_view.xml',
        'views/courier_log.xml',
        'views/courier_group.xml',
        'views/config_rates.xml',
        'views/config_zone.xml',
        'views/config_cities.xml',
        'views/config_provinces.xml',
        'report/stock_report.xml',
        'report/stock_report_template.xml',
        'report/stock_barcode_texmplate.xml',
        'data/self_pickup_seq.xml'

    ],
    'images': [
        'views/src/logo.jpg',
    ],
    
    'installable': True,
    'auto_install': False,
    'application': True,
    'license': 'LGPL-3',
}
